1.Extract the file into specific folder

2. Right click in folder and select the open in terminal

3.write the command 'python -m http.server'

4. Open your any browser and type the "LOCALHOST:8000"

5. Ready to GO
 